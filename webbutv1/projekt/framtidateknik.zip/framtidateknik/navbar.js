document.getElementById("expand").addEventListener("click", () => {
    document.getElementById("navbar").classList.toggle("expanded")
})